## About

A relatively small collection of programs

## License
[MIT](https://choosealicense.com/licenses/mit/)
