#  Python program to check whether an alphabet is vowel or consonant.

# Step 1: Get a character from the user
# Step 2: Check whether the input is vowel or consonant by using the python built-in functions like(lower(), upper()).
# Step 3: If the character is vowel print Vowel otherwise print Consonant
# Step 4: End

x = input("")

if (x == 'A' or x == 'a' or x == 'E' or x == 'e' or x == 'I' or x == 'i' or x == 'O' or x == 'o' or x == 'U' or x == 'u'):
    print("Vowel")
else:
    print("Consonant")

# Input: E
# Output: Vowel
