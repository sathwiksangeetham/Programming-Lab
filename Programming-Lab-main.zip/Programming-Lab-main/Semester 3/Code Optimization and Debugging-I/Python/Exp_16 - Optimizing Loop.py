# Implement Optimizing loop using python.

# Python program to swap two variables
# To take inputs from the user
# x = input('Enter value of x: ')
# y = input('Enter value of y: ')
# create a temporary variable and swap the values

x=2
y=5
temp=x
x=y
y=temp
print(x,y)
x,y=3,5
x,y=y,x
print(x,y)

# Input:

#  5 2
#  5 3

# Output:

#  5 2
#  5 3

